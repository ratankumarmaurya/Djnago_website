# from django.shortcuts import render
# from django.http import HttpResponse
#
# def home (request):
#     return HttpResponse("<h3>Welcome to django</h3>")
#
# def index(request):
#     return render(request,'index.html')
